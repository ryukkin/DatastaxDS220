Disclaimer
===========
By downloading the zip file that contains this README, we assume that you know what you're doing. We recommend using a pre-built exercise environment, which can be found in the Course Assets section. If you do need help with these files, you can ask in the DSE community on the DataStax Academy Slack channel.


Setup Notes
============
N/A
